#include "ChannelViewModel.h"

ChannelViewModel::ChannelViewModel(Data::ChannelRepository* channelRepo, QObject *parent)
    : QAbstractListModel(parent), m_channelRepo(channelRepo)
{
}

int ChannelViewModel::rowCount(const QModelIndex &parent) const {
    if (parent.isValid()) return 0;
    return m_channels.size();
}

QVariant ChannelViewModel::data(const QModelIndex &index, int role) const {
    if (!index.isValid() || index.row() >= m_channels.size()) return QVariant();

    const auto& channel = m_channels[index.row()];

    switch (role) {
        case IdRole: return channel.id;
        case NameRole: return channel.name;
        case StreamUrlRole: return channel.streamUrl;
        case LogoUrlRole: return channel.logoUrl;
        case IsFavoriteRole: return channel.isFavorite;
        default: return QVariant();
    }
}

QHash<int, QByteArray> ChannelViewModel::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[IdRole] = "id";
    roles[NameRole] = "name";
    roles[StreamUrlRole] = "streamUrl";
    roles[LogoUrlRole] = "logoUrl";
    roles[IsFavoriteRole] = "isFavorite";
    return roles;
}

void ChannelViewModel::loadChannels(int groupId) {
    beginResetModel();
    if (m_channelRepo) {
        auto stdList = m_channelRepo->getChannelsByGroupId(groupId);
        m_channels.clear();
        for (const auto& c : stdList) {
            m_channels.append(c);
        }
    }
    endResetModel();
}

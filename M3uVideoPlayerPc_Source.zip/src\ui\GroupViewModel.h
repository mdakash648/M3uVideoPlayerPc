#pragma once

#include <QAbstractListModel>
#include <QList>
#include "../domain/Group.h"
#include "../data/ChannelRepository.h"

class GroupViewModel : public QAbstractListModel {
    Q_OBJECT
public:
    enum GroupRoles {
        IdRole = Qt::UserRole + 1,
        NameRole,
        PlaylistIdRole,
        OrderIndexRole,
        ChannelCountRole
    };

    explicit GroupViewModel(Data::ChannelRepository* channelRepo, QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    Q_INVOKABLE void loadGroups(int playlistId);

private:
    Data::ChannelRepository* m_channelRepo;
    QList<Domain::Group> m_groups;
};

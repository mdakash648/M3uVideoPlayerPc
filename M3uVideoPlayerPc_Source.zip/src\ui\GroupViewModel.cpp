#include "GroupViewModel.h"

GroupViewModel::GroupViewModel(Data::ChannelRepository* channelRepo, QObject *parent)
    : QAbstractListModel(parent), m_channelRepo(channelRepo)
{
}

int GroupViewModel::rowCount(const QModelIndex &parent) const {
    if (parent.isValid()) return 0;
    return m_groups.size();
}

QVariant GroupViewModel::data(const QModelIndex &index, int role) const {
    if (!index.isValid() || index.row() >= m_groups.size()) return QVariant();

    const auto& group = m_groups[index.row()];

    switch (role) {
        case IdRole: return group.id;
        case NameRole: return group.name;
        case PlaylistIdRole: return group.playlistId;
        case OrderIndexRole: return group.orderIndex;
        case ChannelCountRole: return group.channelCount;
        default: return QVariant();
    }
}

QHash<int, QByteArray> GroupViewModel::roleNames() const {
    QHash<int, QByteArray> roles;
    roles[IdRole] = "id";
    roles[NameRole] = "name";
    roles[PlaylistIdRole] = "playlistId";
    roles[OrderIndexRole] = "orderIndex";
    roles[ChannelCountRole] = "channelCount";
    return roles;
}

void GroupViewModel::loadGroups(int playlistId) {
    beginResetModel();
    if (m_channelRepo) {
        auto stdList = m_channelRepo->getGroupsByPlaylistId(playlistId);
        m_groups.clear();
        for (const auto& g : stdList) {
            m_groups.append(g);
        }
    }
    endResetModel();
}

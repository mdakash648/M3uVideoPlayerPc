#pragma once

#include <QAbstractListModel>
#include <QList>
#include "../domain/Channel.h"
#include "../data/ChannelRepository.h"

class ChannelViewModel : public QAbstractListModel {
    Q_OBJECT
public:
    enum ChannelRoles {
        IdRole = Qt::UserRole + 1,
        NameRole,
        StreamUrlRole,
        LogoUrlRole,
        IsFavoriteRole
    };

    explicit ChannelViewModel(Data::ChannelRepository* channelRepo, QObject *parent = nullptr);

    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    QHash<int, QByteArray> roleNames() const override;

    Q_INVOKABLE void loadChannels(int groupId);

private:
    Data::ChannelRepository* m_channelRepo;
    QList<Domain::Channel> m_channels;
};
